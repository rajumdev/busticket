package com.codephillip.app.busticket.provider.base;

public interface BaseModel {
}
